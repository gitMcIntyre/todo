define(
//begin v1.x content
{
	"HKD_displayName": "dòlar de Hong Kong",
	"CHF_displayName": "franc suís",
	"CAD_displayName": "dòlar canadenc",
	"CNY_displayName": "iuan renmimbi xinès",
	"AUD_displayName": "dòlar australià",
	"JPY_displayName": "ien japonès",
	"USD_displayName": "dòlar dels Estats Units",
	"GBP_displayName": "lliura esterlina britànica",
	"EUR_displayName": "euro"
}
//end v1.x content
);