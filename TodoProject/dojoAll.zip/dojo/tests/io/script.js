dojo.provide("tests.io.script");
if(dojo.isBrowser){
	doh.registerUrl("tests.io.script", dojo.moduleUrl("tests.io", "script.html"));
}
