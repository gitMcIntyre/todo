dojo.provide("tests.io.iframe");
if(dojo.isBrowser){
	doh.registerUrl("tests.io.iframe", dojo.moduleUrl("tests.io", "iframe.html"));
}
