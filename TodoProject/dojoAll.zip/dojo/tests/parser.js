dojo.provide("tests.parser");
if(dojo.isBrowser){
	doh.registerUrl("tests.parser", dojo.moduleUrl("tests", "parser.html"));
}
