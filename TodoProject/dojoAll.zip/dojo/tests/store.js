define("dojo/tests/store", ["dojo", "dojo/tests/store/Memory", "dojo/tests/store/DataStore", "dojo/tests/store/Observable", "dojo/tests/store/Cache"].concat(dojo.isBrowser ? ["dojo/tests/store/JsonRest"] : []), function(dojo) {
});


