dojo.provide("tests.fx");
if(dojo.isBrowser){
	doh.registerUrl("tests.fx", dojo.moduleUrl("tests", "fx.html"), 30000);
	doh.registerUrl("tests.NodeList-fx", dojo.moduleUrl("tests", "NodeList-fx.html"));
}
