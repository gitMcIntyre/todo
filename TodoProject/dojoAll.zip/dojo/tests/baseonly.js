dojo.provide("dojo.tests.baseonly");

try{
	dojo.require("tests._base");
}catch(e){
	doh.debug(e);
}
