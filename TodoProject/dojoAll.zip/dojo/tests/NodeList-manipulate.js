dojo.provide("tests.NodeList-manipulate");
if(dojo.isBrowser){
	doh.registerUrl("tests.NodeList-manipulate", dojo.moduleUrl("tests", "NodeList-manipulate.html"));
}
