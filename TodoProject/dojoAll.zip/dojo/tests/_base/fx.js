dojo.provide("tests._base.fx");
if(dojo.isBrowser){
	doh.registerUrl("tests._base.fx", dojo.moduleUrl("tests", "_base/fx.html"), 15000);
}
