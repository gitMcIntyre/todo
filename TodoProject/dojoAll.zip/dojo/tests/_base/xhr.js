dojo.provide("tests._base.xhr");
if(dojo.isBrowser){
	doh.registerUrl("tests._base.xhr", dojo.moduleUrl("tests", "_base/xhr.html"));
}
