// test define statement spread across multiple lines
//
// AMD-id "my/module"
define([
  "your/module",
  "his/module"
], function(yours, his) {

var x= 1;

return x;

});
