// test define statement spread across multiple lines another way
// AMD-id "my/module" some commentary
define(
[
  "your/module",
  "his/module"
], function(yours, his) {

var x= 1;

return x;

});
