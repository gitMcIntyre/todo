dojo.provide("tests._base.query");
if(dojo.isBrowser){
	doh.registerUrl("tests._base.query", dojo.moduleUrl("tests", "_base/query.html"), 60000);
	doh.registerUrl("tests._base.NodeList", dojo.moduleUrl("tests", "_base/NodeList.html"), 60000);
}
