define(function (require, exports, module) {
	exports.five = require("./data").five;
	exports.exports = module.exports;
});