define({
	number: 42
});