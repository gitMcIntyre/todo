define("tests/data/ItemFileReadStore", ["tests/data/readOnlyItemFileTestTemplates", "dojo/data/ItemFileReadStore" ], function() {
  tests.data.readOnlyItemFileTestTemplates.registerTestsForDatastore("dojo.data.ItemFileReadStore");
});

