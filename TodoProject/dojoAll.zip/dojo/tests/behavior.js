dojo.provide("tests.behavior");
if(dojo.isBrowser){
	doh.registerUrl("tests.behavior", dojo.moduleUrl("tests", "behavior.html"));
}
