dojo.provide("tests.back");
if(dojo.isBrowser){
	doh.registerUrl("tests.back", dojo.moduleUrl("tests", "back.html"));
}
