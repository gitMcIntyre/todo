dojo.provide("tests.cookie");
if(dojo.isBrowser){
	doh.registerUrl("tests.cookie", dojo.moduleUrl("tests", "cookie.html"));
}
