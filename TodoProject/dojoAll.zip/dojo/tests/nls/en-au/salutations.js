define(
//begin v1.x content
{
 hello: "G'day"
}
//end v1.x content
);
