define(
//begin v1.x content
{
 ko: "\uD55C\uAD6D\uC5B4",
 hello: "\uc548\ub155"
}
//end v1.x content
);
