define(
//begin v1.x content
{
 fr: "Français",
 hello: "Bonjour"
}
//end v1.x content
);
