define(
//begin v1.x content
{
 hello: "Hujambo"
}
//end v1.x content
);
