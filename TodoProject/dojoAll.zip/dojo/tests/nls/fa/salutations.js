define(
//begin v1.x content
{
 fa: "فارسی",
 hello: "درود"
}
//end v1.x content
);
