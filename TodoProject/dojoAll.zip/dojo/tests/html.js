dojo.provide("tests.html");
if(dojo.isBrowser){
	doh.registerUrl("tests.html", dojo.moduleUrl("tests", "html/test_set.html"));
}
