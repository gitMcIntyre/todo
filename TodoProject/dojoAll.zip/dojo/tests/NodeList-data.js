dojo.provide("tests.NodeList-data");
if(dojo.isBrowser){
	doh.registerUrl("tests.NodeList-data", dojo.moduleUrl("tests", "NodeList-data.html"));
}
