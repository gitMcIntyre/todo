dojo.provide("tests.NodeList-traverse");
if(dojo.isBrowser){
	doh.registerUrl("tests.NodeList-traverse", dojo.moduleUrl("tests", "NodeList-traverse.html"));
}
